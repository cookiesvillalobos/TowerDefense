//
// Created by viviana on 21/04/19.
//


/**
 * ID unico
 * Edad
 * Probabilidad de sobrevir en la next gen
 * Generaciones esperadas de supervivencia (estimado)
 * Inteligencia emocional
 * Condición física
 * Fuerza en tronco superior
 * Fuerza en tronco inferior
 * Resistencia
 **/
#ifndef GLADIADOR_H
#define GLADIADOR_H


class Gladiador {

private:
    int ID_uni;
    int edad;
    int prob_sob_nex_gen;
    int gen_expec_super;
    int inte_emocio;
    int condici_fisic;
    int fuez_tronc_sup;
    int fuez_tronc_inf;
    int resistencia;

    int fitness;

    bool a_star_star;
    bool bread_fi;

    int gen[9];
public:
    void setFitness(int fitness);

    int getFitness();

    const int *getGen();

    int getIdUni() const;

    void setIdUni(int idUni);

    int getEdad() const;

    void setEdad(int edad);

    int getProbSobNexGen() const;

    void setProbSobNexGen(int probSobNexGen);

    int getGenExpecSuper() const;

    void setGenExpecSuper(int genExpecSuper);

    int getInteEmocio() const;

    void setInteEmocio(int inteEmocio);

    int getCondiciFisic() const;

    void setCondiciFisic(int condiciFisic);

    int getFuezTroncSup() const;

    void setFuezTroncSup(int fuezTroncSup);

    int getFuezTroncInf() const;

    void setFuezTroncInf(int fuezTroncInf);

    int getResistencia() const;

    void setResistencia(int resistencia);

    bool isAStarStar() const;

    void setAStarStar(bool aStarStar);

    bool isBreadFi() const;

    void setBreadFi(bool breadFi);


};


#endif //PERSONAJES_GLADIADOR_H
