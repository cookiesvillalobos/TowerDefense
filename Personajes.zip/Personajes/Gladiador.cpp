//
// Created by viviana on 21/04/19.
//

#include "Gladiador.h"

int Gladiador::getIdUni() const {
    return ID_uni;
}

void Gladiador::setIdUni(int idUni) {
    ID_uni = idUni;
    gen[0] = idUni;

}

int Gladiador::getEdad() const {
    return edad;
}

void Gladiador::setEdad(int edad) {
    Gladiador::edad = edad;
    gen[1]=edad;

}

int Gladiador::getProbSobNexGen() const {
    return prob_sob_nex_gen;

}

void Gladiador::setProbSobNexGen(int probSobNexGen) {
    prob_sob_nex_gen = probSobNexGen;
    gen[2]=probSobNexGen;

}

int Gladiador::getGenExpecSuper() const {
    return gen_expec_super;
}

void Gladiador::setGenExpecSuper(int genExpecSuper) {
    gen_expec_super = genExpecSuper;
    gen[3]=gen_expec_super;

}

int Gladiador::getInteEmocio() const {
    return inte_emocio;
}

void Gladiador::setInteEmocio(int inteEmocio) {
    inte_emocio = inteEmocio;
    gen[4]=inteEmocio;

}

int Gladiador::getCondiciFisic() const {
    return condici_fisic;
}

void Gladiador::setCondiciFisic(int condiciFisic) {
    condici_fisic = condiciFisic;
    gen[5]=condiciFisic;

}

int Gladiador::getFuezTroncSup() const {
    return fuez_tronc_sup;
}

void Gladiador::setFuezTroncSup(int fuezTroncSup) {
    fuez_tronc_sup = fuezTroncSup;
    gen[6]=fuezTroncSup;

}

int Gladiador::getFuezTroncInf() const {
    return fuez_tronc_inf;
}

void Gladiador::setFuezTroncInf(int fuezTroncInf) {
    fuez_tronc_inf = fuezTroncInf;
    gen[7]=fuezTroncInf;
}

int Gladiador::getResistencia() const {
    return resistencia;
}

void Gladiador::setResistencia(int resistencia) {
    Gladiador::resistencia = resistencia;
    gen[8]=resistencia;
}

bool Gladiador::isAStarStar() const {
    return a_star_star;
}

void Gladiador::setAStarStar(bool aStarStar) {
    a_star_star = aStarStar;
}

bool Gladiador::isBreadFi() const {
    return bread_fi;
}

void Gladiador::setBreadFi(bool breadFi) {
    bread_fi = breadFi;
}

const int *Gladiador::getGen(){
    return gen;
}

int Gladiador::getFitness(){
    return fitness;
}

void Gladiador::setFitness(int fitness) {
    Gladiador::fitness = fitness;
}



