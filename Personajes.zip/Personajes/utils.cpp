//
// Created by viviana on 25/04/19.
//

#include "utils.h"

/**
 * Funcion que crea los primeros individuos a partir de numeros random
 */
Gladiador utils::crear_individuo() {
    int i = 0;
    int valores[9]; //gen a crear
    int fitness = 0; //fitness del nuevo individuio
    Gladiador gladiador; //nuevo individuo
    while (i<9){
        int num = rand()%10+1; //num random
        valores[i]=num;
        if (num == 1){
            fitness++;//Por cada 1 en el gen el fitnes sube, el perfecto es con todo en 1
        }
        i++;
    }
    //Se añaden todos los valores al nuevo individuo
    gladiador.setIdUni(valores[0]);
    gladiador.setEdad(valores[1]);
    gladiador.setProbSobNexGen(valores[2]);
    gladiador.setGenExpecSuper(valores[3]);
    gladiador.setInteEmocio(valores[4]);
    gladiador.setCondiciFisic(valores[5]);
    gladiador.setFuezTroncSup(valores[6]);
    gladiador.setFuezTroncInf(valores[7]);
    gladiador.setResistencia(valores[8]);
    gladiador.setFitness(fitness);
    return gladiador;
}

/**
 * Funcion que crea la poblacion de gladiadores y los manda a reproducirse
 * @param gladiadores array de todos los gladiadores
 * @param n cantidad de poblaciones hechas
 */
void utils::crear_Poblacion(Gladiador *gladiadores, int n) {
    //Solo la primera vez de la poblacion entra aqui para crear la poblacion inicial
    if (n ==0) {
        int i = 0;
        //crea 200 individuos
        while (i < 200) {
            Gladiador gladiador = crear_individuo();
            gladiadores[i] = gladiador;
            i++;
        }
    }
    calcular_fitness(gladiadores); //obtiene el fitness de la poblacion
    seleccion(gladiadores[0],gladiadores[1],gladiadores); //seleciona los mejores
}

/**
 * Funcion que selecciona los mas fuertes
 * @param madre gladiador madre
 * @param padre gladiador padre
 * @param gladiadores poblacion de gladiadores
 */
void utils::seleccion(Gladiador madre, Gladiador padre, Gladiador *gladiadores) {
    int i = 0;
    int fitness[200];
    while (i<200){
        fitness[i] = gladiadores[i].getFitness();
        i++;
    }
    madre = gladiadores[0];
    padre = gladiadores[1];
    int m = 0;
    int p = 0;
    i = 2;
    //Se buscan los primeros mejores
    while (i<198){
        if (gladiadores[i].getFitness() > madre.getFitness() & m==0){
            madre = gladiadores[i];
            m = 1;
            p = 0;
         }
        else if (gladiadores[i].getFitness() > padre.getFitness() & p==0){
            padre = gladiadores[i];
            p = 1;
            m = 0;
         }
        i++;
    }
    //Los mejores se reproducen
    reproduccion(madre,padre,gladiadores);
}

/**
 * Funcion que reproduce y crea un nuevo individuo
 * @param madre gladiador madre
 * @param padre gladiador padre
 * @param gladiadores poblacion de todos los gladiadores
 */
void utils::reproduccion(Gladiador madre, Gladiador padre, Gladiador *gladiadores) {
    int i = 0;
    int fitness = 0;
    int gen[9]; //Nuevos genes
    int per = rand()%199; //Gladiador a eliminar
    Gladiador gladiador; //Nuevo gladiador

    //Se colocan los nuevos genes
    while (i<9){
        int num = rand()%100;
        if (i<4){
            gen[i] = madre.getGen()[i];

        }
        if (4<i){
            gen[i] = padre.getGen()[i];
        }
        if (num == 2){ //tal vez hay mutacion
            gen[i] = gen[i]+1;
        }
        if (gen[i] == 1){ //El fitness
            fitness++;
        }
        i++;
    }

    gladiador.setIdUni(gen[0]);
    gladiador.setEdad(gen[1]);
    gladiador.setProbSobNexGen(gen[2]);
    gladiador.setGenExpecSuper(gen[3]);
    gladiador.setInteEmocio(gen[4]);
    gladiador.setCondiciFisic(gen[5]);
    gladiador.setFuezTroncSup(gen[6]);
    gladiador.setFuezTroncInf(gen[7]);
    gladiador.setResistencia(gen[8]);
    gladiador.setFitness(fitness);
    gladiadores[per] = gladiador;

}
/**
 * Funcion que determina el fitness de la poblacion total
 * @param gladiadores poblacion de gladiadores
 * @return
 */
void utils::calcular_fitness(Gladiador gladiadores[]) {
    int i = 0;
    int fitness = 0;
    //Se obtiene que cada fitness y se suman al total
    while (i<200){
        fitness = fitness + gladiadores[i].getFitness();
        i++;
    }
    printf (" Fitness: %i \n", fitness);
}
