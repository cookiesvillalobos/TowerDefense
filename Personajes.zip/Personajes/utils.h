//
// Created by viviana on 25/04/19.
//

#include "Gladiador.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#ifndef UTILS_H
#define UTILS_H



class utils {
public:
    Gladiador crear_individuo();
    void crear_Poblacion(Gladiador[200], int);
    void calcular_fitness(Gladiador*);
    void reproduccion(Gladiador, Gladiador, Gladiador*);
    void seleccion(Gladiador, Gladiador, Gladiador*);
};


#endif //UTILS_H
