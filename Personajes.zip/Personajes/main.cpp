#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include "utils.h"

utils utils;


int main() {
    srand(time(NULL));

    Gladiador poblacion[200];

    int modelo[9] = {1,1,1,1,1,1,1,1,1}; //Modelo perfecto
    int largo = 8; //Longitud material genetico
    int cant_indi = 200; //Cantidad de individuos de la poblacion
    int pressure = 10; //cantidad de individuos que se seleccionan por reproduccion
    float muta_por = 0.2; //probabilidad de mutacion
    int i = 0;
    while (i<100){
        utils.crear_Poblacion(poblacion,i);
        i++;
    }



    return 0;
}